import calculator as calc
import string_utils as str_fun
import builtins ##All the builtin functions,exceptions ,constants are defined in the builtin Module

##Example print("Hello") ###Internally print() method calls __builtins__.print("Hello")

## To import only the specific methods from string_utils
#from string_utils import str_palin,concatenate_string

## To import all the methods from string_utils using *
#from string_utils import *

fact_result =calc.factorial(11)
print(f"Factorial of 11 is {fact_result}")

sqr_result=calc.square(11)
print(f"Square of 11 is{sqr_result}")

cube_result=calc.cube(11)
print(f"Cube of 11 is{cube_result}")


rev_string =str_fun.reverse_string("Hello")
print(f" The reversed string is:  {rev_string}")


palindrome_check = str_fun.str_palin("madam")
print(f" Is 'madam' a palindrome?{palindrome_check}")


string_len= str_fun.string_len("hello")
print(f"The string length is {string_len}")

str1="Hello"
str2="World"
concat_str = str_fun.concatenate_string(str1,str2)
print(f"The concatenated string is {concat_str}")

## What is the disadvantage of importing the entire module? Does it occupy more space?
##Ans:" yes" More memory is required when all the Methods are imported.

## what if the module is stored in different directory?
##Go to correct patha nd access it

## There are two types of Module sin python :

#1. User-defined module
#2. built-in module
   #a. Numpy
   #b. math
   #c. Pandas

##Importing built-in functions
import math
print(f"Square root of 16 is :{math.sqrt(16)}")

#Is a built-in function.Here using of math is not required
x=min(1,2,3,4,5)
print(f" The minimum value is{x}")

print(f"The ceil value is {math.ceil(4.2)}")

print(f"The floor value is {math.floor(4.2)}")

print(f"The absolute value is {abs(-4.2)}")

print(f"The factorial is {math.factorial(4)}")

print(f"The pi value  is {math.pi}")

import datetime
today=datetime.date.today()
print(f"Today's date is: {today}")


timestamp=datetime.datetime.now()
print(f"Ttime now is: {timestamp}")

import random ##used to geneerate data randmly
random_number =random.randint(1,10) ##Everytime when it runs it gives a Random number specified int he Range.
print(f"The Random number is{random_number}")

print(f"the randowm number from the list is {random.uniform(1,10)}")

print(f" The random choice from the list is {random.choice(['apple','bananna','cherry'])}")

