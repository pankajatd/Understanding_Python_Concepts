## Reversal of a String
def reverse_string(str1):
    return str1[::-1]


## Palindrome Check
def str_palin(str1):
    reversed_string = str1[::-1]
    return str1==reversed_string


## Concatenation of Two  Srings
def concatenate_string(str1,str2):
    concat_str=str1  +  str2
    return(concat_str)

#3 Check the Length of any String
def string_len(str1):
    return len(str1)
