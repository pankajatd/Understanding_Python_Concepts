## This file is working as a Module where all the required functions are defined

def square(num):
    return (num*num)

def cube(num):
    return(num**3)

def factorial(num):
    ## Base Condition
    if num==0 or num==1 :
        return 1
    else:
        # Recursive Call
     return(num*factorial(num-1))
    

def subtract(num1,num2):
    return(num1-num2)

def multiplication(num1,num2):
    return(num1*num2)

def division(num1,num2):
    return(num1/num2)
    
    